Admiral Awesome

Meagan Bleyer, Mark Hurley, Greg Kilmer - Game 1 : Perspective

Controls:
W - Move Forward
A - Strage Left
S - Move Backward
D - Strage Right
Space Bar - Jump
Left Shift - Sprint
Left Mouse Button - Squish Enemies
Mouse Movement - Move Camera

Gameplay:
Rack up your score by squashing enemies between your fingers.
Line the enemies up and make sure they fit entirely between your fingers to squish them with the Left Mouse Button.
Getting hit by bullets will drop your health, but avoiding them for 4 seconds will allow your health to slowly regenerate.